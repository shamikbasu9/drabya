<?php
$pageTitle = 'Home';
require_once 'includes/header.php';

$conn = getDBConnection();

// Get featured products
$featuredProducts = [];
$result = $conn->query("SELECT p.*, pi.image_path FROM products p 
                        LEFT JOIN product_images pi ON p.id = pi.product_id AND pi.is_primary = TRUE 
                        WHERE p.is_featured = TRUE AND p.status = 'active' 
                        ORDER BY p.stock_quantity > 0 DESC, p.sales_count DESC LIMIT 6");
while ($row = $result->fetch_assoc()) {
    $featuredProducts[] = $row;
}

// Get categories
$categories = [];
$result = $conn->query("SELECT * FROM categories LIMIT 6");
while ($row = $result->fetch_assoc()) {
    $categories[] = $row;
}

$conn->close();
?>

<!-- Hero Section -->
<section class="hero-section py-5 overflow-hidden">
    <div class="container position-relative">
        <!-- Floating Elements Background -->
        <div class="position-absolute top-0 start-0 w-100 h-100 overflow-hidden" style="z-index: 0; opacity: 0.1;">
            <div class="animate-float" style="position: absolute; top: 10%; left: 5%; width: 100px; height: 100px; background: var(--primary); filter: blur(50px); border-radius: 50%;"></div>
            <div class="animate-float" style="position: absolute; bottom: 10%; right: 5%; width: 150px; height: 150px; background: var(--secondary); filter: blur(70px); border-radius: 50%; animation-delay: -2s;"></div>
        </div>

        <div class="row align-items-center position-relative" style="z-index: 1;">
            <div class="col-lg-7 mb-5 mb-lg-0 reveal-up">
                <span class="badge bg-soft-primary text-primary px-3 py-2 rounded-pill mb-3" style="background: rgba(var(--primary-rgb), 0.1);">NEW COLLECTION 2026</span>
                <h1 class="display-3 fw-bold mb-4" style="line-height: 1.1;">
                    Gifts That <span class="text-primary">Speak</span><br>For You.
                </h1>
                <p class="lead mb-5 text-muted" style="max-width: 550px;">
                    Discover premium custom mugs, coasters, fridge magnets, and t-shirts. 
                    Unique merchandise engineered for style and expression.
                </p>
                <div class="d-flex flex-wrap gap-3">
                    <a href="products.php" class="btn btn-primary btn-lg px-5 shadow-lg">
                        <i class="fas fa-bolt me-2"></i> Explore Store
                    </a>
                    <a href="#featured" class="btn btn-outline-primary btn-lg px-5">
                        <i class="fas fa-play me-2"></i> How it Works
                    </a>
                </div>
            </div>
            <div class="col-lg-5 text-center reveal-up" style="transition-delay: 0.2s;">
                <div class="hero-image-container position-relative">
                    <!-- Glassy geometric background shape -->
                    <div class="position-absolute top-50 start-50 translate-middle animate-float" 
                         style="width: 350px; height: 350px; background: var(--glass-bg); backdrop-filter: blur(20px); border: 1px solid var(--glass-border); border-radius: 30% 70% 70% 30% / 30% 30% 70% 70%; z-index: -1;">
                    </div>
                    <i class="fas fa-fire fa-10x text-primary animate-float" style="filter: drop-shadow(0 0 30px rgba(var(--primary-rgb), 0.5));"></i>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Categories -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5 reveal-up">
            <h2 class="fw-bold h1 mb-2">Shop by Category</h2>
            <div class="mx-auto" style="width: 60px; height: 4px; background: var(--primary); border-radius: 2px;"></div>
        </div>
        <div class="row g-4 justify-content-center">
            <?php foreach ($categories as $category): ?>
                <div class="col-6 col-md-4 col-lg-2 reveal-up" style="transition-delay: <?php echo 0.1 * ($category['id'] % 6); ?>s;">
                    <a href="products.php?category=<?php echo $category['id']; ?>" class="text-decoration-none h-100 d-block">
                        <div class="card text-center product-card h-100 p-3" style="border-radius: 24px;">
                            <div class="category-icon-wrapper mb-3 mx-auto d-flex align-items-center justify-content-center" 
                                 style="width: 70px; height: 70px; background: rgba(var(--primary-rgb), 0.05); border-radius: 20px; transition: all 0.3s ease;">
                                <i class="fas <?php echo $category['icon']; ?> fa-2x text-primary"></i>
                            </div>
                            <h6 class="fw-bold text-main m-0"><?php echo htmlspecialchars($category['name']); ?></h6>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Featured Products -->
<section class="py-5 bg-light" id="featured">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold mb-0">Featured Products</h2>
            <a href="products.php" class="btn btn-outline-success">View All</a>
        </div>
        
        <div class="row g-4">
            <?php if (empty($featuredProducts)): ?>
                <div class="col-12 text-center py-5">
                    <i class="fas fa-box-open fa-4x text-muted mb-3"></i>
                    <p class="text-muted">No featured products yet. Check back soon!</p>
                </div>
            <?php else: ?>
                <?php foreach ($featuredProducts as $product): ?>
                    <div class="col-6 col-md-4 col-lg-2 reveal-up" style="transition-delay: <?php echo 0.1 * ($product['id'] % 6); ?>s;">
                        <div class="card product-card h-100 border-0 shadow-sm">
                            <div class="position-relative overflow-hidden">
                                <a href="product-detail.php?id=<?php echo $product['id']; ?>" class="d-block">
                                    <?php if ($product['image_path']): ?>
                                        <img src="<?php echo getProductImageUrl($product['image_path']); ?>" 
                                             class="card-img-top" alt="<?php echo htmlspecialchars($product['title']); ?>"
                                             style="transition: transform 0.6s cubic-bezier(0.165, 0.84, 0.44, 1);">
                                    <?php else: ?>
                                        <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height: 200px;">
                                            <i class="fas fa-box-open fa-3x text-muted"></i>
                                        </div>
                                    <?php endif; ?>
                                </a>
                                <?php if (!empty($product['discount_price']) && $product['discount_price'] < $product['price']): ?>
                                    <span class="position-absolute top-0 start-0 m-2 badge rounded-pill bg-danger shadow">
                                        -<?php echo calculateDiscountPercentage($product['price'], $product['discount_price']); ?>%
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="card-body p-3">
                                <p class="text-muted small mb-1"><?php echo htmlspecialchars($product['category_name'] ?? 'Merchandise'); ?></p>
                                <h6 class="card-title fw-bold mb-2">
                                    <a href="product-detail.php?id=<?php echo $product['id']; ?>" class="text-decoration-none text-main stretched-link">
                                        <?php echo displayTitle($product['title']); ?>
                                    </a>
                                </h6>
                                <div class="d-flex align-items-center justify-content-between mt-auto" style="position: relative; z-index: 2;">
                                    <div>
                                        <?php if (!empty($product['discount_price']) && $product['discount_price'] < $product['price']): ?>
                                            <span class="text-primary fw-bold"><?php echo formatCurrency($product['discount_price']); ?></span>
                                            <span class="text-muted text-decoration-line-through x-small ms-1 d-block" style="font-size: 0.7rem;">
                                                <?php echo formatCurrency($product['price']); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-primary fw-bold"><?php echo formatCurrency($product['price']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <button onclick="event.preventDefault(); addToCart(<?php echo $product['id']; ?>)" 
                                            class="btn btn-primary btn-sm p-2 rounded-circle shadow-sm" 
                                            style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Features -->
<section class="py-5 bg-glass-soft">
    <div class="container">
        <div class="row g-4 text-center">
            <div class="col-md-3 reveal-up">
                <div class="feature-item p-4">
                    <div class="icon-circle mb-4 mx-auto d-flex align-items-center justify-content-center" style="width: 80px; height: 80px; background: rgba(0, 242, 255, 0.1); border-radius: 50%;">
                        <i class="fas fa-truck fa-2x text-info"></i>
                    </div>
                    <h5 class="fw-bold">Fast Delivery</h5>
                    <p class="text-muted small">Reliable flat-rate shipping across India</p>
                </div>
            </div>
            <div class="col-md-3 reveal-up" style="transition-delay: 0.1s;">
                <div class="feature-item p-4">
                    <div class="icon-circle mb-4 mx-auto d-flex align-items-center justify-content-center" style="width: 80px; height: 80px; background: rgba(var(--primary-rgb), 0.1); border-radius: 50%;">
                        <i class="fas fa-shield-alt fa-2x text-primary"></i>
                    </div>
                    <h5 class="fw-bold">Premium Quality</h5>
                    <p class="text-muted small">Double-checked quality for every item</p>
                </div>
            </div>
            <div class="col-md-3 reveal-up" style="transition-delay: 0.2s;">
                <div class="feature-item p-4">
                    <div class="icon-circle mb-4 mx-auto d-flex align-items-center justify-content-center" style="width: 80px; height: 80px; background: rgba(255, 215, 0, 0.1); border-radius: 50%;">
                        <i class="fas fa-headset fa-2x text-warning"></i>
                    </div>
                    <h5 class="fw-bold">24/7 Support</h5>
                    <p class="text-muted small">Specialized team at your service</p>
                </div>
            </div>
            <div class="col-md-3 reveal-up" style="transition-delay: 0.3s;">
                <div class="feature-item p-4">
                    <div class="icon-circle mb-4 mx-auto d-flex align-items-center justify-content-center" style="width: 80px; height: 80px; background: rgba(46, 125, 50, 0.1); border-radius: 50%;">
                        <i class="fas fa-undo fa-2x text-success"></i>
                    </div>
                    <h5 class="fw-bold">Easy Returns</h5>
                    <p class="text-muted small">Hassle-free 7-day return policy</p>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
function addToCart(productId) {
    fetch('cart-action.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=add&product_id=' + productId
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Modern notification instead of alert
            const toast = document.createElement('div');
            toast.className = 'position-fixed bottom-0 start-50 translate-middle-x mb-4 px-4 py-3 bg-dark text-white rounded-pill shadow-lg reveal-up active';
            toast.style.zIndex = '9999';
            toast.innerHTML = '<i class="fas fa-check-circle text-success me-2"></i> Added to cart!';
            document.body.appendChild(toast);
            setTimeout(() => {
                toast.classList.remove('active');
                setTimeout(() => toast.remove(), 600);
            }, 3000);
            
            // Reload count only if needed
            const countBadge = document.querySelector('.badge-notification');
            if (countBadge) {
                countBadge.innerText = parseInt(countBadge.innerText) + 1;
            } else {
                location.reload(); 
            }
        } else {
            alert(data.message || 'Failed to add to cart');
        }
    });
}

// Reveal on Scroll Logic
const observerOptions = {
    threshold: 0.1
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('active');
        }
    });
}, observerOptions);

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.reveal-up').forEach(el => observer.observe(el));
});
</script>

<?php require_once 'includes/footer.php'; ?>
